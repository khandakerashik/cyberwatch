#!/usr/bin/env python3
"""Validate the public snapshot and curated event data without network access."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import ipaddress
import json
from pathlib import Path
import re
from urllib.parse import urlsplit

try:
    from .research_sources import DOMAINS, DATE_BASES, RELEASE_STATUSES, validate_learning
except ImportError:
    from research_sources import DOMAINS, DATE_BASES, RELEASE_STATUSES, validate_learning

ROOT = Path(__file__).resolve().parents[1]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def date(value):
    require(isinstance(value, str), "Dates must be ISO strings")
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        return datetime.fromisoformat(value).replace(tzinfo=timezone.utc)
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    require("T" in value and parsed.tzinfo is not None, "Datetimes must include an explicit timezone")
    return parsed.astimezone(timezone.utc)


def link(value):
    require(isinstance(value, str) and len(value) <= 3000, "Source URL must be a bounded string")
    parsed = urlsplit(value)
    require(parsed.scheme in {"http", "https"} and parsed.hostname and not parsed.username and not parsed.password,
            "Sources require safe HTTP(S) URLs without credentials")
    require(not any(ord(character) < 33 for character in value), "Source URL contains whitespace or controls")


def strings(value, label, maximum=100):
    require(isinstance(value, list) and len(value) <= maximum, f"{label} must be a bounded array")
    require(all(isinstance(item, str) and len(item) <= 10000 for item in value), f"{label} must contain bounded strings")


def image_link(value):
    """Image metadata must not point browsers at local services or executable URLs."""
    link(value)
    parsed = urlsplit(value)
    host = parsed.hostname.lower().rstrip(".")
    require(parsed.scheme == "https" and parsed.port in {None, 443}, "Images require public HTTPS URLs")
    require("\\" not in value and not re.search(r"[<>\"']", value), "Unsafe image URL")
    require(host != "localhost" and "." in host and not host.endswith((".localhost", ".local", ".internal", ".test", ".invalid")),
            "Images cannot target local hostnames")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        require(bool(re.fullmatch(r"[a-z0-9.-]+", host)) and not host.isdigit(), "Unsafe image hostname")
        require(not re.fullmatch(r"[0-9.]+", host), "Noncanonical IP address is not allowed")
    else:
        require(address.is_global, "Images cannot target private or reserved addresses")


def validate_article(article):
    require(isinstance(article, dict), "article must be an object")
    require(article.get("status") in {"full", "excerpt", "unavailable", "restricted"}, "Invalid article availability")
    require(article.get("origin") in {"feed", "publisher"}, "Invalid article origin")
    paragraphs = article.get("paragraphs", [])
    require(isinstance(paragraphs, list) and len(paragraphs) <= 120, "Article paragraphs must be bounded")
    require(all(isinstance(value, str) and value.strip() and len(value) <= 4000 for value in paragraphs),
            "Invalid article paragraph")
    require(sum(len(value) for value in paragraphs) <= 100000, "Article exceeds the text limit")
    require(article.get("status") != "full" or bool(paragraphs), "A full article requires readable text")
    images = article.get("images", [])
    require(isinstance(images, list) and len(images) <= 6, "Article images must be bounded")
    for item in images:
        require(isinstance(item, dict), "Invalid article image")
        image_link(item.get("url"))
        for field in ("alt", "caption", "credit"):
            require(isinstance(item.get(field, ""), str) and len(item.get(field, "")) <= 2000,
                    f"Invalid article image {field}")
    require(isinstance(article.get("note", ""), str) and len(article.get("note", "")) <= 2000, "Invalid article note")
    if article.get("fetchedAt") is not None:
        date(article["fetchedAt"])
    if article.get("lastAttemptAt") is not None:
        require(isinstance(article["lastAttemptAt"], str) and "T" in article["lastAttemptAt"], "Article attempt requires a timestamp")
        date(article["lastAttemptAt"])
    if "availabilityReason" in article:
        require(article["availabilityReason"] in {"full", "publisher-feed-excerpt", "permission-required", "publisher-restricted", "robots-disallowed", "extraction-failed", "reader-limit", "publisher-partial", "headline-only", "no-content", "fetch-failed"}, "Invalid article availability reason")
    for field in ("truncated", "retained"):
        if field in article:
            require(isinstance(article[field], bool), f"article.{field} must be boolean")
    require(article.get("status") != "full" or article.get("truncated") is not True, "Truncated articles cannot be marked full")


def validate_event(event):
    require(isinstance(event, dict), "Each event must be an object")
    require(isinstance(event.get("id"), str) and re.fullmatch(r"[a-zA-Z0-9_-]{1,128}", event["id"]), "Invalid event id")
    for field in ("title", "organization", "summary", "description", "severityBasis", "evidenceNote", "sourceId"):
        require(isinstance(event.get(field), str) and 0 < len(event[field]) <= 12000, f"{event['id']}: missing or invalid {field}")
    require(event.get("severity") in {"critical", "high", "medium", "low", "unknown"}, "Invalid severity")
    require(event.get("category") in {"Incident", "Vulnerability", "Advisory", "Patch", "News"}, "Invalid category")
    require(event.get("stream", "news" if event.get("category") == "News" else "intelligence") in {"intelligence", "news"}, "Invalid event stream")
    require(event.get("sourceType") in {None, "mainstream", "security", "vendor", "government"}, "Invalid event source type")
    if "learning" in event:
        validate_learning(event["learning"])
        require(event.get("category") == "News" and event.get("stream") == "news", "Research records must use the publication stream")
    if "newsRelevance" in event:
        decision = event["newsRelevance"]
        require(isinstance(decision, dict), "newsRelevance must be an object")
        require(type(decision.get("version")) is int and decision["version"] == 1, "Unsupported news relevance version")
        require(isinstance(decision.get("relevant"), bool), "News relevance must be a boolean")
        values = decision.get("matchedKeywords")
        require(isinstance(values, list) and len(values) <= 40 and
                all(isinstance(value, str) and value.strip() and len(value) <= 100 for value in values), "Invalid relevance keywords")
        require(isinstance(decision.get("reason"), str) and 0 < len(decision["reason"]) <= 500, "Invalid relevance reason")
    for field in ("matchedKeywords", "newsTopics"):
        if field in event:
            strings(event[field], field, maximum=40)
            require(all(value.strip() and len(value) <= 100 for value in event[field]), f"Invalid {field}")
    if event.get("article") is not None:
        validate_article(event["article"])
    require(event.get("bangladeshScope") in {None, "national-advisory", "local-activity", "coverage"}, "Invalid Bangladesh scope")
    require(event.get("status") in {"investigating", "active", "mitigated", "resolved", "monitoring"}, "Invalid status")
    require(event.get("confidence") in {"confirmed", "reported"}, "Invalid confidence")
    require(isinstance(event.get("exploited"), bool), "exploited must be boolean")
    date(event.get("publishedAt"))
    date(event.get("updatedAt"))
    require(date(event["updatedAt"]) >= date(event["publishedAt"]), "updatedAt cannot precede publishedAt")
    for field in ("geography", "sectors", "cves", "tags", "impact", "recommendations"):
        strings(event.get(field), field, maximum=500 if field == "cves" else 100)
    if event.get("bangladeshScope"):
        require(any(value.lower() in {"bangladesh", "bd"} for value in event["geography"]), "Bangladesh-scoped events need explicit geography")
    require(all(re.fullmatch(r"CVE-\d{4}-\d{4,}", cve) for cve in event["cves"]), "Invalid CVE identifier")
    require(event["impact"] and event["recommendations"], "Impact and recommendations are required")
    require(isinstance(event.get("sources"), list) and 1 <= len(event["sources"]) <= 30, "Every event needs at least one source")
    for source in event["sources"]:
        require(isinstance(source.get("name"), str) and source["name"], "Every source needs a name")
        link(source.get("url"))
        if source.get("publishedAt") is not None:
            date(source["publishedAt"])
        require(source.get("kind") in {"primary", "secondary"}, "Invalid source kind")
    require(isinstance(event.get("timeline"), list) and len(event["timeline"]) <= 100, "Invalid timeline")
    for entry in event["timeline"]:
        date(entry.get("date"))
        require(all(isinstance(entry.get(field), str) and entry[field] for field in ("title", "description")), "Invalid timeline entry")
    if "technicalDetails" in event:
        details = event["technicalDetails"]
        require(isinstance(details, dict), "technicalDetails must be an object")
        fields = {"affectedSystems", "attackVector", "prerequisites", "detection", "mitigation", "limitations"}
        require(set(details) <= fields | {"reviewedAt"}, "Unsupported technicalDetails field")
        for field in fields:
            if field in details:
                values = details[field]
                require(isinstance(values, list) and len(values) <= 12, f"technicalDetails.{field} must be a bounded array")
                require(all(isinstance(value, str) and value.strip() and len(value) <= 1200 for value in values),
                        f"technicalDetails.{field} must contain nonempty bounded strings")
        if details.get("reviewedAt") is not None:
            date(details["reviewedAt"])


def validate_snapshot(data):
    require(isinstance(data, dict) and data.get("schemaVersion") == 1, "Unsupported snapshot schema")
    date(data.get("generatedAt"))
    for field in ("databaseUpdatedAt", "lastCheckedAt"):
        if field in data:
            require(isinstance(data[field], str) and "T" in data[field], f"{field} must include a full timestamp")
            require(date(data[field]) <= date(data["generatedAt"]), f"{field} cannot be later than snapshot generation")
    require(isinstance(data.get("events"), list) and len(data["events"]) <= 2000, "Invalid event list")
    require(isinstance(data.get("sources"), list) and len(data["sources"]) <= 200, "Missing or oversized source registry")
    source_ids = set()
    for source in data["sources"]:
        require(isinstance(source.get("id"), str) and source["id"] not in source_ids, "Duplicate or invalid source id")
        source_ids.add(source["id"])
        require(source.get("status") in {"ok", "error", "snapshot"}, "Invalid source status")
        require(source.get("kind") in {"primary", "secondary", "curated"}, "Invalid source kind")
        require(source.get("group", "intelligence") in {"intelligence", "news", "bangladesh", "newsboard", "research"}, "Invalid source group")
        if "learning" in source:
            validate_learning(source["learning"])
            require(source.get("group") == "research", "Learning source metadata requires research group")
        require(source.get("sourceType") in {None, "mainstream", "security", "vendor", "government"}, "Invalid source type")
        require(isinstance(source.get("itemCount"), int) and source["itemCount"] >= 0, "Invalid source item count")
        if source.get("url") is not None:
            link(source["url"])
        for field in ("lastSuccessAt", "lastAttemptAt"):
            if source.get(field) is not None:
                date(source[field])
        if "collectionHistory" in source:
            checks = source["collectionHistory"]
            require(isinstance(checks, list) and len(checks) <= 48, "Collection history must contain at most 48 checks")
            require(source.get("kind") != "curated" or not checks, "Curated records cannot claim automated checks")
            last_check = None
            for check in checks:
                require(isinstance(check, dict) and check.get("status") in {"ok", "error"}, "Invalid collection history outcome")
                require(isinstance(check.get("at"), str) and "T" in check["at"], "History check requires a timestamp")
                at = date(check["at"])
                require(last_check is None or at > last_check, "History checks must be unique and ordered")
                require(at <= date(data["generatedAt"]), "Collection history cannot be in the future")
                if source.get("lastAttemptAt"):
                    require(at <= date(source["lastAttemptAt"]), "History cannot follow the last attempt")
                require(isinstance(check.get("recordCount"), int) and not isinstance(check["recordCount"], bool) and 0 <= check["recordCount"] <= 2000, "Invalid history record count")
                last_check = at
    ids = set()
    for event in data["events"]:
        validate_event(event)
        require(event["id"] not in ids, "Duplicate event id")
        require(event["sourceId"] in source_ids, "Event sourceId has no registry entry")
        ids.add(event["id"])
    for source in data["sources"]:
        require(source["itemCount"] == sum(e["sourceId"] == source["id"] for e in data["events"]), "Source count does not match displayed records")
    if "researchWatch" in data:
        require(isinstance(data["researchWatch"], list) and len(data["researchWatch"]) <= 40, "Invalid research watch list")
        watch_ids = set()
        for watch in data["researchWatch"]:
            require(isinstance(watch, dict), "Research watch must be an object")
            identifier = watch.get("id")
            require(isinstance(identifier, str) and re.fullmatch(r"[a-zA-Z0-9_-]{1,128}", identifier) and identifier not in watch_ids, "Invalid or duplicate research watch id")
            watch_ids.add(identifier)
            require(watch.get("sourceId") in source_ids, "Research watch needs a registered source")
            for field in ("name", "currentLabel"):
                require(isinstance(watch.get(field), str) and 0 < len(watch[field]) <= 500, "Invalid research watch label")
            for field in ("url", "referenceUrl"):
                link(watch.get(field))
                require(watch[field].startswith("https://"), "Research watches require HTTPS references")
            domains = watch.get("domains")
            require(isinstance(domains, list) and 1 <= len(domains) <= 8 and all(isinstance(value, str) and value in DOMAINS for value in domains), "Invalid research watch domains")
            require(watch.get("status") in {"ok", "error"}, "Invalid research watch status")
            require(watch.get("watchType") in {"edition", "release"}, "Invalid research watch kind")
            require(watch.get("releaseStatus") in RELEASE_STATUSES and watch.get("dateBasis") in DATE_BASES, "Invalid research watch publication metadata")
            require(isinstance(watch.get("changeDetected"), bool), "Research watch changes must be boolean")
            require(watch.get("error") is None or isinstance(watch["error"], str) and 0 < len(watch["error"]) <= 1000, "Invalid research watch error")
            require(watch.get("contentHash") is None or isinstance(watch["contentHash"], str) and re.fullmatch(r"[a-f0-9]{64}", watch["contentHash"]), "Invalid research watch hash")
            date(watch.get("lastCheckedAt"))
            for field in ("publishedAt", "lastSuccessAt", "firstObservedAt", "changedAt"):
                if watch.get(field) is not None:
                    date(watch[field])
            if watch.get("watchType") == "edition":
                require(watch.get("publishedAt") is None and watch.get("dateBasis") == "observation", "Edition checks cannot invent publication dates")
            if watch.get("status") == "ok":
                require(watch.get("contentHash") and watch.get("firstObservedAt") and watch.get("lastSuccessAt") and watch.get("error") is None, "Successful research watch needs observation evidence")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--file", type=Path, default=ROOT / "dist/data/incidents.json")
    parser.add_argument("--curated", type=Path, default=ROOT / "data/curated.json")
    parser.add_argument("--bangladesh-curated", type=Path, default=ROOT / "data/bangladesh-curated.json")
    args = parser.parse_args()
    data = json.loads(args.file.read_text(encoding="utf-8"))
    validate_snapshot(data)
    curated_count = 0
    for path in (args.curated, args.bangladesh_curated):
        if not path.exists() and path == args.bangladesh_curated:
            continue
        curated = json.loads(path.read_text(encoding="utf-8"))
        require(isinstance(curated, list), "Curated file must contain an array")
        for event in curated:
            validate_event(event)
        curated_count += len(curated)
    print(f"Valid snapshot: {len(data['events'])} records; {len(data['sources'])} sources; {curated_count} curated records.")


if __name__ == "__main__":
    main()
