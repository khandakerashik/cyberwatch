"""CyberWatch live refresh service."""
